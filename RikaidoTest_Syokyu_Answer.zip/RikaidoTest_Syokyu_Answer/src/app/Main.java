package app;

import java.util.Scanner;

import util.MessageConstants;

/**
 * InventoryManagementSystemのメインクラス（エントリーポイント）
 * 
 * <pre>
 * ハンズオン内容：
 *   シンプルな在庫管理システムの作成
 * 目的：
 *   初学者が基本的な制御構文、クラス設計、配列操作、定数の利用を学べる。
 *   在庫管理を通じて、Javaの基本的なプログラム構造を理解する。
 * </pre>
 * 
 * <p>
 * [課題]<br>
 * ・TODOをすべて実装する<br>
 * <br>
 * [挑戦課題]<br>
 * scanner.nextInt()で文字の入力を行うとInputMismatchExceptionが発生する<br>
 * try-catch文を使って、例外をキャッチして対応するメッセージ(定数)を表示せよ
 * 
 * @author 教育PJ
 * @since 2024/8/13
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventory inventory = new Inventory();

        while (true) {
            System.out.print(MessageConstants.MENU_OPTIONS);
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            //挑戦課題　回答例
//            int choice;
//
//            try {
//            	choice = scanner.nextInt();
//			} catch (InputMismatchException e) {
//				System.out.println(MessageConstants.INVALID_INPUT);	
//				continue;
//			}finally {
//	            scanner.nextLine(); 
//			}
            
            switch (choice) {
                case 1:
                    System.out.print(MessageConstants.PRODUCT_NAME_PROMPT);
                    String name = scanner.nextLine();
                    System.out.print(MessageConstants.PRODUCT_QUANTITY_PROMPT);
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); 

                    Product product = new Product(name, quantity);
                    inventory.addProduct(product);
                    break;
                case 2:
                    inventory.displayInventory();
                    break;
                case 3:
                    System.out.print(MessageConstants.PRODUCT_NAME_PROMPT);
                    String searchName = scanner.nextLine();
                    Product foundProduct = inventory.searchProduct(searchName);
                    if (foundProduct != null) {
                        System.out.println("商品: " + foundProduct.getName() + ", 数量: " + foundProduct.getQuantity());
                    } else {
                    	System.out.println(MessageConstants.PRODUCT_NOT_FOUND);
                    }
                    break;
                case 4:
                    System.out.println(MessageConstants.EXIT_MESSAGE);
                    scanner.close();
                    return; // プログラム終了
                default:
                    System.out.println(MessageConstants.INVALID_NUMBER);
            }
        }
    }
}

